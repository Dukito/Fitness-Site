using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.SqlServer;




using FitnessSignupApi.Data;
using FitnessSignupApi.Model;
using System.Threading.Tasks;
[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _context;

    public UsersController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> Register(User user)
    {
        _context.Users.Add(user);
        await _context.SaveChangesAsync();
        return Ok(user);
    }

    [HttpGet]
    public async Task<IActionResult> GetUsers()
    {
        var users = await _context.Users.ToListAsync();
        return Ok(users);
    }
    [HttpPost("login")]
public async Task<IActionResult> Login([FromBody] LoginRequest login)
{
    if (string.IsNullOrWhiteSpace(login.Username) || string.IsNullOrWhiteSpace(login.Password))
        return BadRequest("Username and password are required.");

    var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == login.Username);

    if (user == null || user.Password != login.Password) 
        return Unauthorized("Invalid credentials.");

    return Ok(new { message = "Login successful", userId = user.Id, username = user.Username ?? "NULL_USERNAME"  });

}

}
